<?php $__env->startSection('content'); ?>

    <h1>Add a Books</h1>
    <?php echo Form::open(['action' => 'BookController@store','method' => 'POST','enctype'=>'multipart/form-data']); ?>

        <div class="form-row">
            <div class="form-group col-sm-9">
                <?php echo e(Form::label('title','Name')); ?>

                <?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'Title of the Book'])); ?>

            </div>
            <div class="form-group col-sm-3">
                <?php echo e(Form::label('title','ISBN')); ?>

                <?php echo e(Form::number('isbn','',['class'=>'form-control','placeholder'=>'ISBN'])); ?>

            </div>
            <div class="form-group col-sm-3">
                <?php echo e(Form::label('title','Year of Publish')); ?>

                <?php echo e(Form::selectRange('year_p', 1990, 2018,'', array('class' => 'form-control '))); ?>

            </div>
            <div class="form-group col-sm-3">
                <?php echo e(Form::label('title','Price')); ?>

                <?php echo e(Form::number('price','',['class'=>'form-control ','placeholder'=>'Price'])); ?>

            </div>
            <div class="form-group  col-sm-3">
                <?php echo e(Form::label('title','Medium')); ?>

                <?php echo e(Form::select('medium', ['English' => 'English'
                , 'Sinhala' => 'Sinhala'
                , 'Tamil' => 'Tamil'
                , 'Hindi' => 'Hindi']
                , '', array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group  col-sm-3">
                <?php echo e(Form::label('title','Category')); ?>

                <?php echo e(Form::select('category',
                ['6' => 'Action and adventure'
                , '7' => 'Anthology'
                , '8' => 'Art'
                , '9' => 'Graphic novel'
                , '10' => 'Romance'
                , '11' => 'Thriller'
                , '12' => 'Science fiction'
                , '13' => 'History']
                , '', array('class' => 'form-control'))); ?>

            </div>
            <div class="form-group  col-sm-12">
                <?php echo e(Form::file('cover_image',['class' => 'btn-sm btn btn-outline-primary'])); ?>

            </div>
            <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary '])); ?>

        </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
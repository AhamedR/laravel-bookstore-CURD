<?php $__env->startSection('content'); ?>

    <h1>Books</h1>

    <?php if(count($books) > 0): ?>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card" style="width: 100%;">
                     <div class="card-body">
                         <div class="row">
                             <div class="col-md-4 col-sm-4">
                                 <img style="width:100%" src="/storage/cover_images/<?php echo e($book->image); ?>">
                             </div>
                             <div class="col-md-4 col-sm-4">
                                 <h4 class="card-title"><?php echo e($book->name); ?> | <small style="color: #1d68a7"><?php echo e($book->medium); ?></small></h4>
                                 <small>Author</small>
                                 <p class="card-text"><?php echo e($book->userName); ?></p>
                                 <small>ISBN</small>
                                 <p class="card-text"><?php echo e($book->isbn); ?></p>
                                 <small>Year of Publish</small>
                                 <p class="card-text"><?php echo e($book->year_of_publish); ?></p>
                                 <h5><strong>Rs <?php echo e($book->amount); ?></strong></h5>
                                 <a href="/book/<?php echo e($book->id); ?>" class="btn btn-outline-primary">view</a>
                             </div>
                         </div>

                    </div>
                </div>
            <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No Books Found!</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
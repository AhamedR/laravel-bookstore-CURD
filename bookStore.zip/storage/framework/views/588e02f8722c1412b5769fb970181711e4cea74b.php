<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/book" class="btn btn-outline-info btn-sm">Go Back</a>
    <hr>
    <div class="row">
        <div class="col-md-4 col-sm-4">
            <img style="width:100%" src="/storage/cover_images/<?php echo e($b->image); ?>">
        </div>
        <div class="col-md-4 col-sm-4">
            <h1><?php echo e($b->name); ?></h1>
            <p>Author : <?php echo e($b->userName); ?></p>
            <p>ISBN : <?php echo e($b->isbn); ?></p>
            <p>Year of Publish : <?php echo e($b->year_of_publish); ?></p>
            <p>Medium : <?php echo e($b->medium); ?></p>
            <p>Category : <?php echo e($b->catName); ?></p>
            <h3> Rs <?php echo e($b->amount); ?></h3>
            <hr>
            <?php if(\Illuminate\Support\Facades\Auth::id()==$b->author_id): ?>
            <div class="form-group">
                <a href="/book/<?php echo e($b->id); ?>/edit" class="btn btn-outline-primary">Edit</a>

                <button onclick="deleteConfirm()" class="btn btn-outline-danger ">Delete</button>
            </div>
            <div id="myDIV">
                <?php echo Form::open(['action' => ['BookController@destroy',$b->id],'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method','DELETE')); ?>

                <div class="form-group">
                    <?php echo e(Form::label('title','Are you sure, Do you want to delete this Book? ')); ?>

                    <?php echo e(Form::submit('Yes Delete it!',['class'=>'btn btn-danger btn-sm'])); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        <?php endif; ?>
        </div>
    </div>

    <script>
        var a = document.getElementById("myDIV");
        a.style.display = "none";
        function deleteConfirm() {
            var x = document.getElementById("myDIV");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>